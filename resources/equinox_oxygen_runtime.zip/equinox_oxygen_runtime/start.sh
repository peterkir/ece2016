#!/bin/sh
java -jar org.eclipse.osgi_3.12.0.v20160908-1235.jar -console