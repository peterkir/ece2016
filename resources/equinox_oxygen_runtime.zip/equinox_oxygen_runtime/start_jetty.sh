#!/bin/sh
java -Dorg.osgi.service.http.port=8888 -jar org.eclipse.osgi_3.12.0.v20160908-1235.jar -console